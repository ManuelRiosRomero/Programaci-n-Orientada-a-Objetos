package co.edu.javeriana.citasembajada.modelo;

public class Adulto extends Usuario {

	public Adulto() {
		// TODO Auto-generated constructor stub
	}

	public Double calcularValorVisa(double tarifa) {
		return tarifa;
	}
}
