package co.edu.javeriana.citasembajada.modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public interface IsistemasCitasEmbajada {
	
	
	/**
	 * <p> metood que permite adicionar un solicitante a la lista de Usuarios
	 * </p>
	 * @param numPass
	 * @param nombre
	 * @param paisOrigen
	 * @param ciudadNac
	 * @param fechaNac
	 * @param email
	 */
	public void adicionarSolicitante(HashMap<Integer, Usuario> u);
	
	/**
	 * Permite imprimir los datos de una embajada al retornarlos como String
	 * @return String
	 */
	public String imprimirDatos();
	/**
	 * <p> Permite imprimir los datos de los usuarios retornandolos como String
	 * </p>
	 * @return String
	 */
	public String imprimirUsuarios();
	
	public String imprimirUsuario(int numPass);
	
	/**
	 * <p> Metodo que permite adicionar una Visa a la lista de visas
	 * </p>
	 * @param id
	 * @param tipo
	 * @param tarifa
	 * @param requisito
	 */
	public void adicionarVisa(List<Visa> visas);
	
	/**
	 * <p> Metodo que permite imprimir los datos de visas al retornarlas como String
	 * </p>
	 * @return
	 */
	public String imprimirVisas();
	
	/**
	 * <p> Permite buscar una visa a partir del tipo de visa, y retornarla como un objeto de tipo Visa
	 * </p>
	 * @param tipoVisa tipo de visa
	 * @return Visa
	 */
	public Visa buscarVisa(String tipoVisa);
	
	/**
	 * <p> Metodo que permite retornar como String, los tipos de visa disponibles
	 * </p>
	 * @return String
	 */
	public String tiposVisa();
	
	/**
	 * <p> Permite buscar un usuario a partir del numero del pasaporte y retornar un objeto de tipo usuarios
	 * </p>
	 * @param numPass
	 * @return Usuario
	 */
	public Usuario buscarUsuario(int numPass);
	
	/**
	 * <p> Permite crear una solicitud de Visa de turismo a partir del numero del unico usuario que la solicito
	 * </p>
	 * @param num
	 */
	public int crearSolicitudTurismoIndi(int num);
	
	/**
	 * <p> permite crear una solicitud a visa de turismo a partir de una lista de usuarios
	 * </p>
	 * @param usuarios
	 */
	public int crearSolicitudTurismo(List<Integer> usuarios );
	
	/**
	 * <p> Permite sumar los numeros de pasaporte de los usuarios para asignar la suma al codigo de solicitud
	 * retorna el numero entero
	 * </p>
	 * @param lista de usuarios
	 * @return un entero creado a partir de la lista de usuarios
	 */
	public  int sumaNumPass(List<Usuario> usuarios);
	
	/**
	 * <p> Permite retornar un String de todas las solicitudes creadas
	 * </p>
	 * @return String
	 */
	public String imprimirSolicitud();
	
	/**
	 * <p> Permite crear una solicitud de visa de cualquier tipo menos turismo a un unico usuario
	 * </p>
	 * @param tipo
	 * @param numPass
	 */
	public int crearSolicitudOtrasVisas(String tipo, int numPass);
	
	/**
	 * <p> Permite buscar una solicitud a partir del usuario que se encuentre dentro de ella, retorna un objeto de tipo solicitud
	 * </p>
	 * @param usuario
	 * @return Solicitud
	 */
	public Solicitud buscarSolicitud(Usuario usuario);
	
	/**
	 * <p> Calcula el valor de una visa para un usuario a partir del numero de pasaporte del mismo
	 * </p>
	 * @param numPass numero de pasaporte asociado a la solicitud
	 */
	public String calcularValorVisaPass(int numPass);
	
	/**
	 * <p> Calcula el valor de una visa para un usuario a partir del codigo de solicitud
	 * </p>
	 * @param numPass numero de pasaporte asociado a la solicitud
	 */
	public String calcularValorVisaCod(int cod);
	
	/**
	 * <p>Busca una unica solicitud de una fecha en especifico
	 * </p>
	 * @param fecha
	 * @return Solicitud
	 */
	public List<Solicitud> buscarSolicitudFecha(String fecha);
	
	/**
	 * <p> Retorna un String con las solicitudes de una determinada fecha como parametro
	 * </p>
	 * @param fecha
	 * @return String
	 */
	public String imprimirSolicitudesFecha(String fecha);
	
	/**
	 * <p> Retorna un String con los requisitos de un tipo de visa 
	 * </p>
	 * @param tipo
	 * @return String
	 */
	public String imprimirRequisitos(String tipo);
	
	/**
	 * <p> Permite asignarle una fecha de cita a una solicitud
	 * </p>
	 * @param sol
	 * @return
	 */
	public LocalDate asignarFecha(Solicitud sol);
	
}
