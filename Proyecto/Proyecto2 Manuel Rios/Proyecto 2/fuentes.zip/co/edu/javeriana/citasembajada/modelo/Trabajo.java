package co.edu.javeriana.citasembajada.modelo;

public class Trabajo extends Visa {

	private String empresa;
	private String carrgo;
	
	public Trabajo() {
		// TODO Auto-generated constructor stub
	}

	public Trabajo(String empresa, String carrgo) {
		super();
		this.empresa = empresa;
		this.carrgo = carrgo;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getCarrgo() {
		return carrgo;
	}

	public void setCarrgo(String carrgo) {
		this.carrgo = carrgo;
	}

	public String imprimirVisa() {
		String visa = "\n"+"\n"+"Id: "+super.getId()+"\n"+"Tipo de Visa: Trabajo"+"\n"+"Tarifa: "+super.getTarifa() +"\n"+ super.getRequisitos();
		return visa;
	}
	
	public void agregarSolicitud() {
		
	}
	
}
