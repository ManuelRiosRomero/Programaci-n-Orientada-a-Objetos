package co.edu.javeriana.citasembajada.persistencia;
import co.edu.javeriana.citasembajada.presentacion.*;
import co.edu.javeriana.citasembajada.modelo.*;
	import java.io.*;
import java.time.LocalDate;
import java.util.*;

import co.edu.javeriana.citasembajada.modelo.Requisito;
import co.edu.javeriana.citasembajada.modelo.SistemaCitasEmbajada;
import co.edu.javeriana.citasembajada.modelo.Usuario;
import co.edu.javeriana.citasembajada.modelo.Visa;
import co.edu.javeriana.citasembajada.presentacion.ControladorCitasEmbajada;
import co.edu.javeriana.citasembajada.presentacion.Utils;
	
public class ManejoArchivos implements Serializable{
	
	public static final String CARPETA_DATA = ".\\data\\";
	
		private static ManejoArchivos ma=new ManejoArchivos();
		static ControladorCitasEmbajada c = new ControladorCitasEmbajada();
		
		/**
		 * <p>Metodo que permite leer un archivo txt con las embajadas, y selecionar aquella que contiene el pais ingresado como parametro
		 * </p>
		 * @param nom
		 * @param pais
		 */
		public static SistemaCitasEmbajada LeerEmbajadas(String nom, String pais){
		
			ManejoArchivos manejoArchivo=new ManejoArchivos();
			SistemaCitasEmbajada sce = new SistemaCitasEmbajada();
			try{
			
				InputStreamReader input=new InputStreamReader(new FileInputStream(nom));
					
				BufferedReader bufferReader =new BufferedReader(input);
				String linea=bufferReader.readLine();
			
				linea=bufferReader.readLine();
				linea=bufferReader.readLine();
				while (!linea.equalsIgnoreCase("#FIN")){	
					String [] partes = linea.split("\\*");
					if(pais.equalsIgnoreCase(partes[1].trim())) {
						
						sce.setId(Integer.parseInt(partes[0].trim()));
						sce.setPaisEmbajada(partes[1].trim());
						sce.setMoneda(partes[2].trim());
						String impuesto =partes[3].trim();
						String impuesto2 = impuesto.substring(0,impuesto.length()-1);
						sce.setImpuesto(Float.parseFloat(impuesto2));
						sce.setCambioOficial(Double.parseDouble(partes[4].trim()));
					}						
					linea=bufferReader.readLine();
										
				}// Fin del while
				//System.out.println(c.imprimirEmbajadas());
			}
			catch (Exception e){
				System.out.println("Ocurrio un problema al cargar el archivo de texto " + e);
			}
			return sce;
		}

		/**
		 * <p>Metodo que permite leer un archivo txt con los solicitantes </p>
		 * @param nom
		 */
		public static HashMap<Integer, Usuario> LeerSolicitantes (String nom){
			
			HashMap <Integer, Usuario> usuarios = new HashMap<Integer, Usuario>();
				ManejoArchivos manejoArchivo=new ManejoArchivos();
				try{
				
					InputStreamReader input=new InputStreamReader(new FileInputStream(nom));
						
				 BufferedReader bufferReader =new BufferedReader(input);
				String linea=bufferReader.readLine();
				linea=bufferReader.readLine();
				linea=bufferReader.readLine();
				int edad = 0;
				while (!linea.equalsIgnoreCase("#FIN")){	
					
					Usuario u = new Usuario();
					Ni�o0a2 menor = new Ni�o0a2();
					Ni�o2a12 joven = new Ni�o2a12();
					Adulto adulto = new Adulto();
					AdultoMayor adultoMayor = new AdultoMayor();
						String [] partes = linea.split("\\*");
						edad= Utils.edadEnAnnos(LocalDate.parse(partes[4].trim()));
						
						
						u.setEmail(partes[5].trim());
						if(edad<3) {
							menor.setNumPasaporte(Integer.parseInt(partes[0].trim()));
							menor.setNombre(partes[1].trim());
							menor.setPaisNacimiento(partes[2].trim());
							menor.setCiudadNacimiento(partes[3].trim());
							menor.setFechaNacimiento(LocalDate.parse(partes[4].trim()));
							menor.setEmail(partes[5].trim());
							//menor.setAcudiente(partes[6].trim());
							usuarios.put(menor.getNumPasaporte(), menor);
						}
						if(2<edad&&edad<18) {
							joven.setNumPasaporte(Integer.parseInt(partes[0].trim()));
							joven.setNombre(partes[1].trim());
							joven.setPaisNacimiento(partes[2].trim());
							joven.setCiudadNacimiento(partes[3].trim());
							joven.setFechaNacimiento(LocalDate.parse(partes[4].trim()));
							joven.setEmail(partes[5].trim());
							//joven.setEscolaridad(partes[6].trim());
							usuarios.put(joven.getNumPasaporte(), joven);
						}
						if(17<edad&&edad<60) {
							adulto.setNumPasaporte(Integer.parseInt(partes[0].trim()));
							adulto.setNombre(partes[1].trim());
							adulto.setPaisNacimiento(partes[2].trim());
							adulto.setCiudadNacimiento(partes[3].trim());
							adulto.setFechaNacimiento(LocalDate.parse(partes[4].trim()));
							adulto.setEmail(partes[5].trim());
							usuarios.put(adulto.getNumPasaporte(), adulto);
						}
						if(60<edad) {
							adultoMayor.setNumPasaporte(Integer.parseInt(partes[0].trim()));
							adultoMayor.setNombre(partes[1].trim());
							adultoMayor.setPaisNacimiento(partes[2].trim());
							adultoMayor.setCiudadNacimiento(partes[3].trim());
							adultoMayor.setFechaNacimiento(LocalDate.parse(partes[4].trim()));
							adultoMayor.setEmail(partes[5].trim());
							usuarios.put(adultoMayor.getNumPasaporte(), adultoMayor);
						}
						linea=bufferReader.readLine();
		            
				}// Fin del while
				//System.out.println(c.imprimirUsuarios());
			
				}
				catch (Exception e){
					System.out.println("Ocurrio un problema al cargar el archivo de texto " + e);
				}
				System.out.println("Tam�o: "+usuarios.size());
				return usuarios;
			}
		/**
		 * <p>Metodo que permite leer un archivo txt con las visas  </p>
		 * @param nom
		 */
		public static List<Visa> LeerVisas (String nom){
			System.out.println("Entra a LeerVisas");
				List<Visa> visas = new ArrayList();
				try{
					System.out.println("Entra al Try");
				
					InputStreamReader input=new InputStreamReader(new FileInputStream(nom));
					BufferedReader bufferReader =new BufferedReader(input);
					String linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					
					Turismo turismo = new Turismo();
					Estudiante estudiante = new Estudiante();
					Trabajo trabajo = new Trabajo();
					Conyuge conyuge = new Conyuge();
					String [] partes = linea.split("\\*");
				while (!linea.equalsIgnoreCase("#FIN")){
					
					
					String requisitos="";
					System.out.println(partes[0].trim());
					System.out.println(partes[2].trim());
					turismo.setId(Integer.parseInt(partes[0].trim()));
					turismo.setTarifa(Double.parseDouble(partes[2].trim()));
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					while(!linea.equalsIgnoreCase("#VISA")&&!linea.equalsIgnoreCase("#FIN")) {
						requisitos+="\n"+linea;
						linea=bufferReader.readLine();
					}
					turismo.setRequisitos(requisitos);
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					visas.add(turismo);
					
					System.out.println(partes[0].trim());
					System.out.println(partes[2].trim());
					estudiante.setId(Integer.parseInt(partes[0].trim()));
					estudiante.setTarifa(Double.parseDouble(partes[2].trim()));
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					requisitos="";
					while(!linea.equalsIgnoreCase("#VISA")&&!linea.equalsIgnoreCase("#FIN")) {
						requisitos+="\n"+linea;
						linea=bufferReader.readLine();
					}
					estudiante.setRequisitos(requisitos);
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					visas.add(estudiante);
					
					System.out.println(partes[0].trim());
					System.out.println(partes[2].trim());
					trabajo.setId(Integer.parseInt(partes[0].trim()));
					trabajo.setTarifa(Double.parseDouble(partes[2].trim()));
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					requisitos="";
					while(!linea.equalsIgnoreCase("#VISA")&&!linea.equalsIgnoreCase("#FIN")) {
						requisitos+="\n"+linea;
						linea=bufferReader.readLine();
					}
					trabajo.setRequisitos(requisitos);
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					visas.add(trabajo);
					
					System.out.println(partes[0].trim());
					System.out.println(partes[2].trim());
					conyuge.setId(Integer.parseInt(partes[0].trim()));
					conyuge.setTarifa(Double.parseDouble(partes[2].trim()));
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					requisitos="";
					while(!linea.equalsIgnoreCase("#VISA")&&!linea.equalsIgnoreCase("#FIN")) {
						requisitos+="\n"+linea;
						linea=bufferReader.readLine();
					}
					conyuge.setRequisitos(requisitos);
					linea=bufferReader.readLine();
					linea=bufferReader.readLine();
					visas.add(conyuge);
					
				}// Fin del while
				}
				catch (Exception e){
					System.out.println("Ocurrio un problema al cargar el archivo de texto " + e);
				}
				return visas;
			}

		
		
		/**
		 *<p>Metodo que permite leer un archivo txt con acompa�antes adiconales y asociarlos a un usuario primario </p> 
		 * @param nom
		 * @param numPasaporte
		 */
		public static List<Integer> LeerAcompa�antes (String nom, int numPasaporte){
			
			List<Integer> pasaportes = new ArrayList();
				ManejoArchivos manejoArchivo=new ManejoArchivos();
				try{
					
					pasaportes.add(numPasaporte);
					InputStreamReader input=new InputStreamReader(new FileInputStream(nom));
						
				 BufferedReader bufferReader =new BufferedReader(input);
				String linea=bufferReader.readLine();
				
				linea=bufferReader.readLine();
				linea=bufferReader.readLine();
				
				while (!linea.equalsIgnoreCase("#FIN")){	
					
						String [] partes = linea.split("\\*");
						
						int numPass = Integer.parseInt(partes[0].trim());
						
						//System.out.println(numPass);
						pasaportes.add(numPass);
						
						linea=bufferReader.readLine();
		            
				}// Fin del while
				
				
				return pasaportes;
				//System.out.println("\n"+"-------------Impresion Manejo de Archivos----------"+"\n"+c.imprimirSolicitud());
				}
				catch (Exception e){
					System.out.println("Ocurrio un problema al cargar el archivo de texto " + e);
				}
				return null;
			}
		
		// Metodo que permite Escribir a un archivo de texto	
		public static void EscribirAArchivoTexto(String texto, String nombre){
		
			try{
	 	      	// Se crea el flujo de salida al archivo de nombre nomarch
	        	OutputStreamWriter out= new OutputStreamWriter(new FileOutputStream(nombre));
	        	//Escribe una cadena en el flujo        	
	        	out.write(texto);
	        	out.close();
	        }
	    		catch(Exception e){
	    			System.out.println("Ocurrio un error escribiendo a un archivo el reporte: " + e); 	
	        }
	    		
		}

		
		
}
