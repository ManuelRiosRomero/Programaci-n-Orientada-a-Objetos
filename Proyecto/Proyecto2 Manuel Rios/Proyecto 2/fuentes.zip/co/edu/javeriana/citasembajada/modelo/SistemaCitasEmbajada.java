package co.edu.javeriana.citasembajada.modelo;
import co.edu.javeriana.citasembajada.persistencia.*;
import co.edu.javeriana.citasembajada.presentacion.Utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

public class SistemaCitasEmbajada implements IsistemasCitasEmbajada{
	private int id;
	private String paisEmbajada;// Pa�s donde se encuentra la embajada
	private String moneda;
	private double cambioOficial;
	private float impuesto;
	private List<Visa> visasLista;
	private List<Solicitud> solicitudesLista;
	private HashMap<Integer, Usuario> mapaUsuarios;
	
	
	
	public SistemaCitasEmbajada() {
		super();
		
		visasLista = new ArrayList();
		solicitudesLista = new ArrayList();
		mapaUsuarios = new HashMap<Integer, Usuario>();
		
	}
	
	public SistemaCitasEmbajada(int id, String paisEmbajada, String moneda, double cambioOficial, float impuesto,
			List<Visa> visasLista, List<Solicitud> solicitudesLista, HashMap<Integer, Usuario> mapaUsuarios) {
		super();
		this.id = id;
		this.paisEmbajada = paisEmbajada;
		this.moneda = moneda;
		this.cambioOficial = cambioOficial;
		this.impuesto = impuesto;
		this.visasLista = visasLista;
		this.solicitudesLista = solicitudesLista;
		this.mapaUsuarios = mapaUsuarios;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getPaisEmbajada() {
		return paisEmbajada;
	}

	public void setPaisEmbajada(String paisEmbajada) {
		this.paisEmbajada = paisEmbajada;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public double getCambioOficial() {
		return cambioOficial;
	}

	public void setCambioOficial(double cambioOficial) {
		this.cambioOficial = cambioOficial;
	}

	public float getImpuesto() {
		return impuesto;
	}

	public void setImpuesto(float impuesto) {
		this.impuesto = impuesto;
	}

	public List<Visa> getVisasLista() {
		return visasLista;
	}

	public void setVisasLista(List<Visa> visasLista) {
		this.visasLista = visasLista;
	}

	public List<Solicitud> getSolicitudesLista() {
		return solicitudesLista;
	}

	public void setSolicitudesLista(List<Solicitud> solicitudesLista) {
		this.solicitudesLista = solicitudesLista;
	}
	
	public HashMap<Integer, Usuario> getMapaUsuarios() {
		return mapaUsuarios;
	}

	public void setMapaUsuarios(HashMap<Integer, Usuario> mapaUsuarios) {
		this.mapaUsuarios = mapaUsuarios;
	}

	/**
	 * <p> metood que permite adicionar un solicitante a la lista de Usuarios
	 * </p>
	 * @param numPass
	 * @param nombre
	 * @param paisOrigen
	 * @param ciudadNac
	 * @param fechaNac
	 * @param email
	 */
	public void adicionarSolicitante(HashMap<Integer, Usuario> u) {
		mapaUsuarios.putAll(u);
		
	}
	
	/**
	 * Permite imprimir los datos de una embajada al retornarlos como String
	 * @return String
	 */
	public String imprimirDatos() {
		String embajada = "Id: "+id +" Pais: "+paisEmbajada+ " Moneda: "+moneda+" Impuesto: "+impuesto+" Tasa de Cambio: "+cambioOficial;
		return embajada;
	}
	/**
	 * <p> Permite imprimir los datos de los usuarios retornandolos como String
	 * </p>
	 * @return String
	 */
	public String imprimirUsuarios() {
		Usuario u = new Usuario();
		String usuarios="Usuarios: ";
		
		for(Integer key:  mapaUsuarios.keySet()) {
			u = mapaUsuarios.get(key);
			if(u!=null) {
				usuarios+=u.imprimirDatos();
				if(u instanceof Ni�o0a2) {
					usuarios+=" Ni�o 0 a 2";
				}
				if(u instanceof Ni�o2a12) {
					usuarios+=" Ni�o 2 a 12";
				}
				if(u instanceof Adulto) {
					usuarios+=" Adulto";
				}
				if(u instanceof AdultoMayor) {
					usuarios+=" Adulto Mayor";
				}
				
			}
		}
		
		
		return usuarios;
	}
	
	public String imprimirUsuario(int numPass) {
		String usuario= "Usuario Solicitado: ";
		Usuario u = mapaUsuarios.get(numPass);
		usuario+=u.imprimirDatos();
		
		return usuario;
	}
	
	/**
	 * <p> Metodo que permite adicionar una Visa a la lista de visas
	 * </p>
	 * @param id
	 * @param tipo
	 * @param tarifa
	 * @param requisito
	 */
	public void adicionarVisa(List<Visa> visas) {
		
		visasLista.addAll(visas);
		//visasLista.addAll(visas);
	}
	
	/**
	 * <p> Metodo que permite imprimir los datos de visas al retornarlas como String
	 * </p>
	 * @return
	 */
	public String imprimirVisas() {
		String visas= "Visas: ";
		for(Visa Vaux: visasLista) {
			if(Vaux!=null) {
				visas+=Vaux.imprimirVisa();
			}
		}
		return visas;
	}
	
	/**
	 * <p> Permite buscar una visa a partir del tipo de visa, y retornarla como un objeto de tipo Visa
	 * </p>
	 * @param tipoVisa tipo de visa
	 * @return Visa
	 */
	public Visa buscarVisa(String tipoVisa) {
		for(Visa v: visasLista) {
			if(v!=null) {
				if(tipoVisa.equalsIgnoreCase("turismo")) {
					if(v instanceof Turismo) {
						return v;
					}
				}
				if(tipoVisa.equalsIgnoreCase("Estudiante")) {
					if(v instanceof Estudiante) {
						return v;
					}
				}
				if(tipoVisa.equalsIgnoreCase("Conyuge")) {
					if(v instanceof Conyuge) {
						return v;
					}
				}
				if(tipoVisa.equalsIgnoreCase("Trabajo")) {
					if(v instanceof Trabajo) {
						return v;
					}
				}
			}
		}
		return null;		
	}
	
	/**
	 * <p> Metodo que permite retornar como String, los tipos de visa disponibles
	 * </p>
	 * @return String
	 */
	public String tiposVisa() {
		String tipos = "Tipos: ";
		for(Visa v: visasLista) {
			if(v!=null) {
				if(v instanceof Turismo) {
					tipos+="- Turismo -";
				}
				if(v instanceof Trabajo) {
					tipos+="- Trabajo -";
				}
				if(v instanceof Estudiante) {
					tipos+="- Estudiante -";
				}
				if(v instanceof Conyuge) {
					tipos+="- Conyuge -";
				}
				}
			}
		return tipos;
		}
	
	/**
	 * <p> Permite buscar un usuario a partir del numero del pasaporte y retornar un objeto de tipo usuarios
	 * </p>
	 * @param numPass
	 * @return Usuario
	 */
	public Usuario buscarUsuario(int numPass) {
		Usuario u = new Usuario();
		for(Integer key:  mapaUsuarios.keySet()) {
			u = mapaUsuarios.get(key);
			if(u!=null) {
				if(numPass==u.getNumPasaporte()) {
					return u;
				}
			}
		}
		return null;
	}
	
	/**
	 * <p> Permite crear una solicitud de Visa de turismo a partir del numero del unico usuario que la solicito
	 * </p>
	 * @param num
	 */
	public int crearSolicitudTurismoIndi(int num){
		Usuario u = new Usuario();
		List<Usuario> uL = new ArrayList();
		u = buscarUsuario(num);
		uL.add(u);
		Solicitud s = new Solicitud();
		s.setVisa(buscarVisa("turismo"));
		s.setUsuarios(uL);
		s.setCodigo(Utils.aleatorio());
		s.setConsecutivo(s.getConsecutivo());
		s.setFecha(asignarFecha(s));
		solicitudesLista.add(s);
		return s.getCodigo();
	}
	
	/**
	 * <p> permite crear una solicitud a visa de turismo a partir de una lista de usuarios
	 * </p>
	 * @param usuarios
	 */
	public int crearSolicitudTurismo(List<Integer> usuarios, int dias ) {
		
		Solicitud s = new Solicitud();
		Turismo v = new Turismo();
		v=(Turismo)buscarVisa("turismo");
		v.setDiasEstadia(dias);
		s.setVisa(v);
		
		List<Usuario> usrs = new ArrayList();
		List<Usuario> uL = new ArrayList();
		Usuario u = new Usuario();
		for(int i: usuarios) {
			for(Integer key:  mapaUsuarios.keySet()) {
				if(usrs!=null) {
					u=mapaUsuarios.get(key);
					if(i==u.getNumPasaporte()) {
						usrs.add(u);
					}
				}
			}
		}
		
		s.setUsuarios(usrs);
		s.setCodigo(sumaNumPass(usrs));
		s.setConsecutivo(s.getConsecutivo());
		s.setFecha(asignarFecha(s));
		for(Usuario ux:usrs) {
			if(ux!=null) {
				ux.setSolicitud(s);
				uL.add(ux);
			}
		}
		s.setUsuarios(uL);
		solicitudesLista.add(s);
		return s.getCodigo();
	}
	
	/**
	 * <p> Permite sumar los numeros de pasaporte de los usuarios para asignar la suma al codigo de solicitud
	 * retorna el numero entero
	 * </p>
	 * @param lista de usuarios
	 * @return un entero creado a partir de la lista de usuarios
	 */
	public  int sumaNumPass(List<Usuario> usuarios) {
		int suma=0;
		for(Usuario u: usuarios) {
			if(u!=null) {
				suma+=u.getNumPasaporte();
			}
		}
		return suma;
	}
	
	/**
	 * <p> Permite retornar un String de todas las solicitudes creadas
	 * </p>
	 * @return String
	 */
	public String imprimirSolicitud() {
		String st = "Solicitudes: "+"\n";
		for(Solicitud s: solicitudesLista) {
			if(s!=null) {
				
						if(s.getVisa() instanceof Turismo) {
							st+="\n"+"Tipo de Visa: Turismo"
							+"\n"+"Dias de estadia: "+s.getVisa().darDias() ;
							
						}
						if(s.getVisa() instanceof Trabajo) {
							st+="\n"+"Tipo de Visa: Trabajo";
						}
						if(s.getVisa() instanceof Estudiante) {
							st+="\n"+"Tipo de Visa: Estudiante";
						}
						if(s.getVisa() instanceof Conyuge) {
							st+="\n"+"Tipo de Visa: Conyuge";
						}
						st+="\n"+"Valor Consecutivo: "+s.getConsecutivo()
						+"\n"+"Estado de solicitud: "+s.getEstado()
						+"\n"+"Codigo de Solicitud: "+Integer.toString(s.getCodigo())
						+"\n"+"Fecha de Solicitud: "+s.getFecha().toString()
						+"\n"+s.imprimirUsuarios()
						+"\n-------------------------------------------------";
			}
		}
		
		return st;
	}
	
	/**
	 * <p> Permite crear una solicitud de visa de cualquier tipo menos turismo a un unico usuario
	 * </p>
	 * @param tipo
	 * @param numPass
	 */
	public int crearSolicitudOtrasVisas(String tipo, int numPass) {
		Usuario u = new Usuario();
		u=buscarUsuario(numPass);
		List<Usuario> usrs = new ArrayList();
		usrs.add(u);
		Solicitud s = new Solicitud();
		s.setVisa(buscarVisa(tipo));
		s.setUsuarios(usrs);
		s.setCodigo(Utils.aleatorio());
		s.setConsecutivo(s.getConsecutivo());
		s.setFecha(asignarFecha(s));
		solicitudesLista.add(s);
		return s.getCodigo();
	}
	
	/**
	 * <p> Permite crear una solicitud de visa de cualquier tipo menos turismo a un unico usuario
	 * </p>
	 * @param tipo
	 * @param numPass
	 */
	public int crearSolicitudOtrasVisas(String tipo, int numPass, String S1, String S2) {
		Usuario u = new Usuario();
		u=buscarUsuario(numPass);
		List<Usuario> usrs = new ArrayList();
		usrs.add(u);
		Solicitud s = new Solicitud();
		Visa v = new Visa();
		v=buscarVisa(tipo);
		Trabajo trabajo = new Trabajo();
		Estudiante estudiante = new Estudiante();
		
		if(v instanceof Trabajo) {
			trabajo.setEmpresa(S1);
			trabajo.setCarrgo(S2);
			s.setVisa(trabajo);
		}
		if(v instanceof Estudiante) {
			estudiante.setEscolaridad(S1);
			estudiante.setInstitucion(S2);
			s.setVisa(estudiante);
		}
		s.setUsuarios(usrs);
		s.setCodigo(Utils.aleatorio());
		s.setConsecutivo(s.getConsecutivo());
		s.setFecha(asignarFecha(s));
		solicitudesLista.add(s);
		return s.getCodigo();
	}
	
	
	/**
	 * <p> Permite buscar una solicitud a partir del usuario que se encuentre dentro de ella, retorna un objeto de tipo solicitud
	 * </p>
	 * @param usuario
	 * @return Solicitud
	 */
	public Solicitud buscarSolicitud(Usuario usuario) {
		for(Solicitud s: solicitudesLista) {
			if(s!=null) {
				for(Usuario u: s.getUsuarios()) {
					if(u!=null) {
						if(u.equals(usuario)) {
							return s;
						}
					}
				}
			}
		}
		return null;
	}
	
	/**
	 * <p> Calcula el valor de una visa para un usuario a partir del numero de pasaporte del mismo
	 * </p>
	 * @param numPass numero de pasaporte asociado a la solicitud
	 */
	public String calcularValorVisaPass(int numPass) {
		int total=0;
		String valor="\n";
		Usuario u = new Usuario();
		u=buscarUsuario(numPass);
		Solicitud s = new Solicitud();
		s= buscarSolicitud(u);
		if(s.getUsuarios()!=null) {
			for(Usuario ux: s.getUsuarios()) {
				if(ux!=null) {
				double tarifa= s.getVisa().getTarifa();
				ux.setValorVisa(tarifa);
				total+=((impuesto/100)*ux.getValorVisa()+ux.calcularValorVisa(s.getVisa().getTarifa()));
				}
			}
			for(Usuario ux: s.getUsuarios()) {
			valor+="\n"+"\n"+"Numero Pasaporte: "+ ux.getNumPasaporte() 
				+"\n"+"Nombre: "+ux.getNombre()
				+"\n"+"Fecha de Nacimiento: "+ux.getFechaNacimiento().toString()
				+"\n"+"Valor Visa: "+ux.getValorVisa()
				+"\n"+"Impuesto: "+((impuesto/100)*ux.getValorVisa())
				+"\n"+"Valor Total: "+((impuesto/100)*ux.getValorVisa()+ux.calcularValorVisa(s.getVisa().getTarifa()))
				+"\n";			
			}
			valor+="\n"+"-------------El valor Total de la visa es-------------"
					+"\n"+"Valor total: "+total+ " --- "
					+"Tasa de Cambio: "+cambioOficial+ " --- "
					+"Conversion("+moneda+"): "+ total/cambioOficial;
		}	
		return valor;
	}
	
	/**
	 * <p> Calcula el valor de una visa para un usuario a partir del codigo de solicitud
	 * </p>
	 * @param numPass numero de pasaporte asociado a la solicitud
	 */
	public String calcularValorVisaCod(int cod) {
		Double total=0.0;
		String valor="\n";
		double tarifa= 0.0;
		Solicitud s = new Solicitud();
		for(Solicitud ss: solicitudesLista) {
			if(ss!=null) {
				if(ss.getCodigo()==cod) {
					s=ss;
				}
			}
		}
		
		
		for(Usuario ux: s.getUsuarios()){
			if(ux!=null) {
				tarifa= s.getVisa().getTarifa();
				ux.setValorVisa(tarifa);
				total+=((impuesto/100)*ux.calcularValorVisa(s.getVisa().getTarifa())+ux.calcularValorVisa(s.getVisa().getTarifa()));
				valor+="\n"+"\n"+"Numero Pasaporte: "+ ux.getNumPasaporte() 
				+"\n"+"Nombre: "+ux.getNombre()
				+"\n"+"Fecha de Nacimiento: "+ux.getFechaNacimiento().toString()
				+"\n"+"Valor Visa: "+ux.getValorVisa()
				+"\n"+"Impuesto: "+((impuesto/100)*ux.calcularValorVisa(s.getVisa().getTarifa()))
				+"\n"+"Valor Total: "+((impuesto/100)*ux.calcularValorVisa(s.getVisa().getTarifa())+ux.calcularValorVisa(s.getVisa().getTarifa()))
				+"\n";	
			}
		}
		valor+="\n"+"-------------El valor Total de la visa es-------------"
				+"\n"+"Valor total: "+total+ " --- "
				+"Tasa de Cambio: "+cambioOficial+ " --- "
				+"Conversion("+moneda+"): "+ total/cambioOficial;
		
		return valor;
	}
	
	/**
	 * <p>Busca una unica solicitud de una fecha en especifico
	 * </p>
	 * @param fecha
	 * @return Solicitud
	 */
	public List<Solicitud> buscarSolicitudFecha(String fecha) {
		LocalDate fechaD;
		fechaD=LocalDate.parse(fecha);
		List<Solicitud> solicitudes = new ArrayList();
		for(Solicitud s: solicitudesLista) {
			if(s!=null) {
				if(s.getFecha().equals(fechaD)) {
					solicitudes.add(s);
				}
			}
		}
		return solicitudes;
	}
	
	/**
	 * <p> Retorna un String con las solicitudes de una determinada fecha como parametro
	 * </p>
	 * @param fecha
	 * @return String
	 */
	public String imprimirSolicitudesFecha(String fecha){
		List<Solicitud> s = new ArrayList();
		s.addAll(buscarSolicitudFecha(fecha));
		String st = "---------REPORTE DE SOLICITUDES---------"
				+"\n Reporte Fecha "+fecha+" : ";
		
		for(Solicitud sx: s) {
			for(Usuario ux: sx.getUsuarios()) {
				if(ux!=null) {
					st+="\n"+"\n"+"NumPass: "+Integer.toString(ux.getNumPasaporte())+
							"\n"+"Nombre: "+ux.getNombre();	
							if(ux.getSolicitud().getVisa() instanceof Turismo) {
								st+="\n"+"Tipo de Visa: Turismo";
							}
							if(ux.getSolicitud().getVisa() instanceof Trabajo) {
								st+="\n"+"Tipo de Visa: Trabajo";
							}
							if(ux.getSolicitud().getVisa() instanceof Estudiante) {
								st+="\n"+"Tipo de Visa: Estudiante";
							}
							if(ux.getSolicitud().getVisa() instanceof Conyuge) {
								st+="\n"+"Tipo de Visa: Conyuge";
							}
							st+="\n"+"Numero de Solicitud: "+sx.getCodigo();
				}
			}
		}
		return st;
	}
	
	/**
	 * <p> Retorna un String con los requisitos de un tipo de visa 
	 * </p>
	 * @param tipo
	 * @return String
	 */
	public String imprimirRequisitos(String tipo) {
		Visa v = new Visa();
		String s=null;
		v=buscarVisa(tipo);
		
		s= v.getRequisitos();
		
		return s;
	}
	
	/**
	 * <p> Permite asignarle una fecha de cita a una solicitud
	 * </p>
	 * @param sol
	 * @return
	 */
	public LocalDate asignarFecha(Solicitud sol) {
		return Utils.nuevaFecha(solicitudesLista);
	}

	@Override
	public int crearSolicitudTurismo(List<Integer> usuarios) {
		// TODO Auto-generated method stub
		return 0;
	}
/**
 * retorna String con lista de beneficiarios por us edad
 * @return
 */
	public String imprimirBeneficiarios() {
		String lista="";
		for(Solicitud s: solicitudesLista) {
			lista+= s.imprimirBeneficiarios();
		}
		return lista;
	}

	
	
	
}
