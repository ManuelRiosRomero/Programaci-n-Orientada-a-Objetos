package co.edu.javeriana.citasembajada.modelo;

public class Turismo extends Visa{

	private int diasEstadia;
	
	public Turismo() {
		// TODO Auto-generated constructor stub
	}

	public Turismo(int diasEstadia) {
		super();
		this.diasEstadia = diasEstadia;
	}

	public int getDiasEstadia() {
		return diasEstadia;
	}

	public void setDiasEstadia(int diasEstadia) {
		this.diasEstadia = diasEstadia;
	}
	
	public String imprimirVisa() {
		String visa = "\n"+"\n"+"Id: "+super.getId()+"\n"+"Tipo de Visa: Turismo"+"\n"+"Tarifa: "+super.getTarifa() +"\n"+ super.getRequisitos();
		return visa;
	}
	
	public void agregarSolicitud() {
		
	}
	
	public int darDias() {
		return diasEstadia;
	}
	
}
