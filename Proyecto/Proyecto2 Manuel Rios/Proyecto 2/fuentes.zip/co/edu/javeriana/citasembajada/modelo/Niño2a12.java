package co.edu.javeriana.citasembajada.modelo;

import co.edu.javeriana.citasembajada.presentacion.Utils;

public class Ni�o2a12 extends Usuario{

	private String escolaridad;
	
	public Ni�o2a12() {
		// TODO Auto-generated constructor stub
	}
	
	public Ni�o2a12(String escolaridad) {
		super();
		this.escolaridad = escolaridad;
	}
	
	public String getEscolaridad() {
		return escolaridad;
	}

	public void setEscolaridad(String escolaridad) {
		this.escolaridad = escolaridad;
	}

	/**
	 * retorna double con valor de la visa de este usuario
	 */
	public Double calcularValorVisa(double tarifa){
		Double total=0.0;
		Double anhos = (double) (18 - Utils.edadEnAnnos(super.getFechaNacimiento()));
		total += tarifa-(tarifa*(0.05* anhos));
		
		if(super.getSolicitud().getVisa() instanceof Turismo) {
			total += total+(tarifa*(0.20));
		}
		if(super.getSolicitud().getVisa() instanceof Estudiante) {
			total += total-(tarifa*(0.30));
		}
		
		return total;
	}
	
	
}
