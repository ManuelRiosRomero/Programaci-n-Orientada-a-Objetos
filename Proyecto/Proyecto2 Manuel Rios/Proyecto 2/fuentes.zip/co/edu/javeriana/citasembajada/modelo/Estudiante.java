package co.edu.javeriana.citasembajada.modelo;

public class Estudiante extends Visa{
	
	private String escolaridad;
	private String institucion;
	public Estudiante() {
		// TODO Auto-generated constructor stub
	}
	public Estudiante(String escolaridad, String institucion) {
		super();
		this.escolaridad = escolaridad;
		this.institucion = institucion;
	}
	public String getEscolaridad() {
		return escolaridad;
	}
	public void setEscolaridad(String escolaridad) {
		this.escolaridad = escolaridad;
	}
	public String getInstitucion() {
		return institucion;
	}
	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}
	
	public String imprimirVisa() {
		String visa = "\n"+"\n"+"Id: "+super.getId()+"\n"+"Tipo de Visa: Estudiante"+"\n"+"Tarifa: "+super.getTarifa() +"\n"+ super.getRequisitos();
		return visa;
	}

}
