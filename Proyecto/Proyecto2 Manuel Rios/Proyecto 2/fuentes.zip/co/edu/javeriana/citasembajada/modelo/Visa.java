package co.edu.javeriana.citasembajada.modelo;
import co.edu.javeriana.citasembajada.presentacion.*;
import co.edu.javeriana.citasembajada.persistencia.*;
import java.util.ArrayList;
import java.util.List;

public class Visa {
	protected int id;
	protected double tarifa;
	protected String requisitos;
	
	public Visa() {
		
	}
	

	public Visa(int id, double tarifa, String requisitos) {
		super();
		this.id = id;
		this.tarifa = tarifa;
		this.requisitos = requisitos;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTarifa() {
		return tarifa;
	}

	public void setTarifa(double tarifa) {
		this.tarifa = tarifa;
	}
	
	public String getRequisitos() {
		return requisitos;
	}


	public void setRequisitos(String requisitos) {
		this.requisitos = requisitos;
	}

/**
 * <p>Agrega todos los atributos de una visa a un unico String para luego imprimir en interfaz consola 
 * </p>
 * @return String
 */
	public String imprimirVisa() {
		
		String visa = "\n"+"\n"+"Id: "+id+"\n"+"Tarifa: "+tarifa +"\n"+ requisitos;
		return visa;

	}
	
	public int darDias() {
		int dias=0;
		return dias;
	}
		
	
	
	

}
