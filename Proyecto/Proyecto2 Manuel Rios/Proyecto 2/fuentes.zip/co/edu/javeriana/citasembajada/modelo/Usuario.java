package co.edu.javeriana.citasembajada.modelo;
import co.edu.javeriana.citasembajada.presentacion.*;
import co.edu.javeriana.citasembajada.persistencia.*;
import co.edu.javeriana.citasembajada.presentacion.Utils;

import java.time.LocalDate;

public  class Usuario {
	protected String nombre;
	protected int numPasaporte;
	protected String email;
	protected LocalDate fechaNacimiento;
	protected String paisNacimiento;
	protected String ciudadNacimiento;
	protected Solicitud solicitud;
	protected double valorVisa;
	
	public Usuario() {
		
	}
	
	public Usuario(String nombre, int numPasaporte, String email, LocalDate fechaNacimiento, String paisNacimiento,
			String ciudadNacimiento, Solicitud solicitud, double valorVisa) {
		super();
		this.nombre = nombre;
		this.numPasaporte = numPasaporte;
		this.email = email;
		this.fechaNacimiento = fechaNacimiento;
		this.paisNacimiento = paisNacimiento;
		this.ciudadNacimiento = ciudadNacimiento;
		this.solicitud = solicitud;
		this.valorVisa = valorVisa;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumPasaporte() {
		return numPasaporte;
	}

	public void setNumPasaporte(int numPasaporte) {
		this.numPasaporte = numPasaporte;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getPaisNacimiento() {
		return paisNacimiento;
	}

	public void setPaisNacimiento(String paisNacimiento) {
		this.paisNacimiento = paisNacimiento;
	}

	public String getCiudadNacimiento() {
		return ciudadNacimiento;
	}

	public void setCiudadNacimiento(String ciudadNacimiento) {
		this.ciudadNacimiento = ciudadNacimiento;
	}
	
	public Solicitud getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(Solicitud solicitud) {
		this.solicitud = solicitud;
	}
	
	public double getValorVisa() {
		return valorVisa;
	}

	public void setValorVisa(double valorVisa) {
		this.valorVisa = valorVisa;
	}

	public void asociarSolicitud(Solicitud s) {
		solicitud=s;
	}

	/**
	 * <p> Agrega todos los valores de un usuario a un String para luego imprimir en Interfaz Consola
	 * </p>
	 * @return String
	 */
	public String imprimirDatos() {
		String usuario = "\n"+"\n"+"Numero Pasaporte: "+ Integer.toString(numPasaporte) +"\n"+"Nombre: "+nombre+"\n"+"Pais de Origen: "+paisNacimiento+"\n"+"Ciudad de Nacimiento: "+ciudadNacimiento
				+"\n"+"Fecha de Nacimiento: "+fechaNacimiento.toString() +"\n"+"Email: "+email+"\n"+"Edad: "+Utils.edadEnAnnos(getFechaNacimiento());
		
		return usuario;
	}
	
	public Double calcularValorVisa(double tarifa) {
		return null;
	}
	

}
