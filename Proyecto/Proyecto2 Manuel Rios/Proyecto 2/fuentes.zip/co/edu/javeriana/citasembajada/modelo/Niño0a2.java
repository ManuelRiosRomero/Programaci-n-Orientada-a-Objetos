package co.edu.javeriana.citasembajada.modelo;

public class Ni�o0a2 extends Usuario {

	private String acudiente;
	
	public Ni�o0a2() {
		// TODO Auto-generated constructor stub
	}

	public String getAcudiente() {
		return acudiente;
	}

	public void setAcudiente(String acudiente) {
		this.acudiente = acudiente;
	}

	public Ni�o0a2(String acudiente) {
		super();
		this.acudiente = acudiente;
	}
	
	public Double calcularValorVisa(double tarifa){
		Double total=0.0;
		total =tarifa-(tarifa*0.90);
		return total;
	}

}
